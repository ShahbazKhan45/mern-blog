import React from 'react'

const About = () => {
    return (
        <div className='mb-20'>
            <h1 className='font-bold sm:text-4xl text-2xl mb-4'>About Page</h1>
            <p className="leading-relaxed mt-2">Lorem ipsum dolor sit amet consectetur adipisicing elit.
                Harum veniam ex eaque possimus officiis magni hic eveniet
                ipsa magnam rerum, eligendi natus consequatur, dolorem ullam
                fugiat tenetur necessitatibus omnis provident itaque impedit!
                Sit sint consequatur maxime nihil! Dolorum recusandae voluptatem
                dignissimos magni quos voluptate a earum, vitae nobis sunt at!
            </p>
            <p className="leading-relaxed mt-2">Lorem ipsum dolor sit amet consectetur adipisicing elit.
                Harum veniam ex eaque possimus officiis magni hic eveniet
                ipsa magnam rerum, eligendi natus consequatur, dolorem ullam
                fugiat tenetur necessitatibus omnis provident itaque impedit!
                Sit sint consequatur maxime nihil! Dolorum recusandae voluptatem
                dignissimos magni quos voluptate a earum, vitae nobis sunt at!
            </p>
            <p className="leading-relaxed mt-2">Lorem ipsum dolor sit amet consectetur adipisicing elit.
                Harum veniam ex eaque possimus officiis magni hic eveniet
                ipsa magnam rerum, eligendi natus consequatur, dolorem ullam
                fugiat tenetur necessitatibus omnis provident itaque impedit!
                Sit sint consequatur maxime nihil! Dolorum recusandae voluptatem
                dignissimos magni quos voluptate a earum, vitae nobis sunt at!
            </p>    
        </div>
    )
}

export default About;