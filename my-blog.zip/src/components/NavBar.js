import React from 'react'
import { Link } from 'react-router-dom';

const NavBar = () => {
  return (
    <div className="container text-center font-bold fixed text-lg text-white bg-gray-400 w-lg">
        <ul className="menu">
            <li className="inline-block p-4">
                <Link to="/">Home</Link>
            </li>
            <li className="inline-block p-4">
                <Link to="/about">About</Link>
            </li>
            <li className="inline-block p-4">
                <Link to="/articles">Articles</Link>
            </li>
            <li className="inline-block p-4">
                <Link to="/articlesList">ArticlesList</Link>
            </li>
        </ul>
    </div>
  )
}

export default NavBar;