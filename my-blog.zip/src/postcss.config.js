module.exports = {
    plugin:[require("tailwindcss"), require("autoprefixer")],
};